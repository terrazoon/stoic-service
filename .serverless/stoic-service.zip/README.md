# Stoic Service

This is a Python/Serverless project that allows people to subscribe to receive daily random Stoic quotes via email.

## Getting Started


### Installing


## Running the tests

### Break down into end to end tests

### And coding style tests

## Deployment

## Built With


## Contributing


## Versioning

Version 0.1

## Authors

* **Kenneth Kehl** - *Initial work* - [terrazoon](https://github.com/terrazoon)

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

## Acknowledgments

Hat tip to Seneca, Epictetus, and Marcus Aurelius.

## TODO
1. custom domain
2. fix permissions on SES
3. decide what to do about images
4. more quotes
5. UI?